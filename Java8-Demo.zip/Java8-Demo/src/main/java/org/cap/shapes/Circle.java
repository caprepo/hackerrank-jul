package org.cap.shapes;

public class Circle {
	
	public Circle() {
		System.out.println("no Argument Constructor....");
	}
	
	public void draw() {
		System.out.println("draw Circle....");
	}
	
	public static void calculateArea() {
		System.out.println("Circle Area Calculation here...");
	}

}
