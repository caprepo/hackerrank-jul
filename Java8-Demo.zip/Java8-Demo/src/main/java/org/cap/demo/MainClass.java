package org.cap.demo;

import org.cap.shapes.Circle;

//import static org.cap.shapes.Circle.*;


public class MainClass {

	public static void main(String[] args) {
		Circle circle=new Circle();
		//calculateArea();
		//circle.calculateArea();
		
		
		//Method References for static method
		Shape shape=Circle::calculateArea;
		shape.display();
		
		//Method References for instance method
		Shape shape2=new Circle()::draw;
		shape2.display();
		
		//Mthod ref for Constructor
		Shape newObj=Circle::new;
		newObj.display();
		
		
		
		
	}

}
