package org.cap.demo;

public class Demo {

	public static void main(String[] args) {
		
		double ans=Math.ceil(1.5);
		double ans1=Math.ceil((float)3/2);
		System.out.println(ans1);

	}

}
