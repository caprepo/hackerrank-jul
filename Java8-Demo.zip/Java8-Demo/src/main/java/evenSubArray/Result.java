package evenSubArray;
import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;


class Result {

    /*
     * Complete the 'evenSubarray' function below.
     *
     * The function is expected to return an INTEGER.
     * The function accepts following parameters:
     *  1. INTEGER_ARRAY numbers
     *  2. INTEGER k
     */

    public static int evenSubarray(List<Integer> numbers, int k) {
    	
    	List<Integer> nums=null;
    	HashSet<List<Integer>> subarr=new HashSet<>();
    	
    	int count=0,oddcount=0;
    	
    	for(int i=0;i<=numbers.size();i++) {
    		nums=new ArrayList<Integer>();
    		
    		for(int j=i+1;j<=numbers.size();j++) {
    			{
    				//Sub Array
    				nums =numbers.subList(i, j);
    				
    				//Sub Array exists in HashSet
    				if(!subarr.contains(nums)) {
    					
    					//Add subArray into HashSet
	    				subarr.add(nums);
	    				//Odd count zero
	    				oddcount=0;
	    				for(int n:nums) {
	    					if(n%2!=0)
	    						oddcount++;
	    				}
	    				if(oddcount<=k)
	    					count++;
    				}
    			}
    		}
    		
    	}
    	System.out.println(subarr);
    	System.out.println("output:"+ count);
    	return count;
    }

}