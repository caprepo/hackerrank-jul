package org.cap.predicate;

import java.util.function.Predicate;

@FunctionalInterface
public interface MyPredicate extends Predicate<UserLogin>{

	
}
