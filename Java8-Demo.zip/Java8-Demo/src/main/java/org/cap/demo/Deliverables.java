package org.cap.demo;

public abstract class Deliverables implements Printable{

	

}
