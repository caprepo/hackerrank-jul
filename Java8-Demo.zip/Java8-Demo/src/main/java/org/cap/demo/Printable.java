package org.cap.demo;

@FunctionalInterface
public interface Printable {

	int print(String msg);
	
	public default void show() {
		System.out.println("Printable Show method...");
	}
	
	public static void display() {
		System.out.println("Printable Static Method....");
	}
	
}
