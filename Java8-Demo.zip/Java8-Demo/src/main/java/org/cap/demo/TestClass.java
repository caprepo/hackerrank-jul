package org.cap.demo;

public class TestClass {

	public static void main(String[] args) {
		
		Printable.display();
		//Printable printable=new Deliverables();
		
		//printable.show();
		
		
		//Printable printable2=() -> System.out.println("printable print method invoked...");
		
		Printable printable2=(msg) -> {
			int num=10,sum=0;
			for(int i=0;i<num;i++)
				sum+=i;
			System.out.println(msg + "  ,printable print method invoked...");
			//System.out.println("Sum:" + sum);
			return sum;
		};
		int result=printable2.print("Good Afternoon!");
		System.out.println("Sum:" + result);
		
	}

}
