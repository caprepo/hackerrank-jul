package org.cap.stream.demo;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class StreamDemo {

	
	public static void main(String[] args) {
	 List<String> list= Arrays.asList("one","tow","two","three",
			 "tom","pooja","jack","annie","ram","john","george");
		
	//Stream<String> seqStream= list.stream();
	 Stream<String> parllelStream= list.parallelStream();
	//processStream(seqStream);
	 processStream(parllelStream);
	 
	}
	
	
	
	public static void processStream(Stream<String> str) {
		str.forEach( (element) ->{
			System.out.println(element.toUpperCase() +  "--->" +
					Thread.currentThread().getName() +"--->" +
					LocalDateTime.now()
					);
		});
		
		
	}
	
	
	
	
	
	
	
	
	
	

}
