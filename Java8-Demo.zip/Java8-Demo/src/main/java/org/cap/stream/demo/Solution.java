package org.cap.stream.demo;

import java.util.ArrayList;
import java.util.List;

public class Solution {
	// Recursive function to print all possible subarrays  
	// for given array  
	static void printSubArrays(String arr, int start, int end) 
	{   
		List<Integer> num=new ArrayList<>();
		num.add(Integer.parseInt(arr.substring(start,end+1)));
		
		if(start==arr.length())
			return;
		
		else {
		
			System.out.println();
			for(int i=end;i<arr.length();i++) {
				System.out.println(i + "-->" + end+i);
				if((end+i)<=arr.length())
				num.add(Integer.parseInt(arr.substring(i,end+i)));
				
				//System.out.print(arr.substring(i,end+i) + ",");
			}
		System.out.println(num);
		System.out.println(start + "===>" +end);
		printSubArrays(arr, 0,end+1); 
		}
	    return; 
	} 
	  
	public static void main(String args[]) 
	{ 
	//int []arr = {1,1,3,7,3}; 
	String arr="11373";
	for(int i=0;i<arr.length();i++)
		printSubArrays(arr, 0,i+1); 
	  
	} 
	} 