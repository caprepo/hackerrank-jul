package org.cap.demo;

@FunctionalInterface
public interface Shape {

	public void display();
}
